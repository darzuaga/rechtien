<?php
// Cores
require_once trailingslashit(CDHL_PATH) . 'includes/cpts/cores/extended-cpts.php';
require_once trailingslashit(CDHL_PATH) . 'includes/cpts/cores/extended-taxos.php';
// CPTs
require_once trailingslashit(CDHL_PATH) . 'includes/cpts/testimonials.php';
require_once trailingslashit(CDHL_PATH) . 'includes/cpts/teams.php';
require_once trailingslashit(CDHL_PATH) . 'includes/cpts/faqs.php';
require_once trailingslashit(CDHL_PATH) . 'includes/cpts/dealer_forms/inquiry.php';
require_once trailingslashit(CDHL_PATH) . 'includes/cpts/dealer_forms/schedule_test_drive.php';
require_once trailingslashit(CDHL_PATH) . 'includes/cpts/dealer_forms/make_an_offer.php';
require_once trailingslashit(CDHL_PATH) . 'includes/cpts/dealer_forms/financial_form.php';
require_once trailingslashit(CDHL_PATH) . 'includes/cpts/cars.php';
require_once trailingslashit(CDHL_PATH) . 'includes/cpts/export/export_log.php';
require_once trailingslashit(CDHL_PATH) . 'includes/cpts/import/import_log.php';
require_once trailingslashit(CDHL_PATH) . 'includes/cpts/geo_fencing.php';
require_once trailingslashit(CDHL_PATH) . 'includes/cpts/promocodes.php';